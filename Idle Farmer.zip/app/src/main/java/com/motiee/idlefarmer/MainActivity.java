package com.motiee.idlefarmer;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity {

    private int level = 1;
    private int exp = 0;
    private int expNeeded = 100;
    private int gold = 100;
    private int diamonds = 0;
    private int wheat = 0;
    private int wood = 0;
    private int shroom = 0;
    private int fish = 0;
    private int ore = 0;

    private int farmSize = 1;
    private int axeLevel = 1;
    private int mushroomFarm = 1;
    private int fishingRod = 1;
    private int pickaxeLevel = 1;
    private int clickPower = 1;
    private int clickPowerLevel = 1;
    private int passiveIncomeLevel = 0;
    private int critChanceLevel = 0;

    private Random random = new Random();
    private Handler handler = new Handler();
    private Runnable passiveRunnable;

    private boolean autoFarmEnabled = false;
    private boolean autoMineEnabled = false;
    private boolean autoFishEnabled = false;
    private int autoSpeed = 3;
    private Handler autoHandler = new Handler();
    private Runnable autoRunnable;

    private ImageButton btnMenu;
    private LinearLayout menuPanel;
    private LinearLayout forestPanel;
    private LinearLayout craftPanel;
    private Switch swAutoFarm;
    private Switch swAutoMine;
    private Switch swAutoFish;
    private SeekBar seekSpeed;
    private boolean menuVisible = false;

    private TextView tvLevel;
    private TextView tvExp;
    private TextView tvGold;
    private TextView tvDiamonds;
    private TextView tvWheat;
    private TextView tvWood;
    private TextView tvShroom;
    private TextView tvFish;
    private TextView tvOre;
    private TextView tvFarmSize;
    private TextView tvAxeLevel;
    private TextView tvMushroomFarm;
    private TextView tvFishingRod;
    private TextView tvPickaxe;
    private ProgressBar progressExp;
    private TextView tvMessage;

    private NotificationManager notificationManager;
    private static final int NOTIFICATION_ID = 999;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Create notification channel for Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(
                "farming_channel",
                "Farming Progress",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows your farming progress");
            notificationManager.createNotificationChannel(channel);
        }

        initViews();
        setupListeners();
        loadGameData();
        startPassiveIncome();
        startAutoFeatures();
        updateUI();
    }

    private void showNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, "farming_channel")
                .setContentTitle("🌾 Idle Farmer")
                .setContentText("Gold: " + gold + " | Wheat: " + wheat + " | Level: " + level)
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pendingIntent)
                .setAutoCancel(false)
                .build();
        } else {
            notification = new Notification.Builder(this)
                .setContentTitle("🌾 Idle Farmer")
                .setContentText("Gold: " + gold + " | Wheat: " + wheat + " | Level: " + level)
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pendingIntent)
                .setAutoCancel(false)
                .build();
        }

        notificationManager.notify(NOTIFICATION_ID, notification);
    }

    private void initViews() {
        tvLevel = findViewById(R.id.tvLevel);
        tvExp = findViewById(R.id.tvExp);
        tvGold = findViewById(R.id.tvGold);
        tvDiamonds = findViewById(R.id.tvDiamonds);
        progressExp = findViewById(R.id.progressExp);
        tvMessage = findViewById(R.id.tvMessage);

        tvWheat = findViewById(R.id.tvWheat);
        tvWood = findViewById(R.id.tvWood);
        tvShroom = findViewById(R.id.tvShroom);
        tvFish = findViewById(R.id.tvFish);
        tvOre = findViewById(R.id.tvOre);

        tvFarmSize = findViewById(R.id.tvFarmSize);
        tvAxeLevel = findViewById(R.id.tvAxeLevel);
        tvMushroomFarm = findViewById(R.id.tvMushroomFarm);
        tvFishingRod = findViewById(R.id.tvFishingRod);
        tvPickaxe = findViewById(R.id.tvPickaxe);

        btnMenu = findViewById(R.id.btnMenu);
        menuPanel = findViewById(R.id.menuPanel);
        forestPanel = findViewById(R.id.forestPanel);
        craftPanel = findViewById(R.id.craftPanel);

        swAutoFarm = findViewById(R.id.swAutoFarm);
        swAutoMine = findViewById(R.id.swAutoMine);
        swAutoFish = findViewById(R.id.swAutoFish);
        seekSpeed = findViewById(R.id.seekSpeed);
    }

    private void setupListeners() {
        findViewById(R.id.btnFarm).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); doFarming(); }
            });

        findViewById(R.id.btnMine).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); doMining(); }
            });

        findViewById(R.id.btnFish).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); doFishing(); }
            });

        findViewById(R.id.btnForest).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); toggleForest(); }
            });

        findViewById(R.id.btnCraft).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); toggleCraft(); }
            });

        btnMenu.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { animateButton(v); toggleMenu(); }
            });

        swAutoFarm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    autoFarmEnabled = isChecked; saveGameData(); restartAuto();
                }
            });

        swAutoMine.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    autoMineEnabled = isChecked; saveGameData(); restartAuto();
                }
            });

        swAutoFish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    autoFishEnabled = isChecked; saveGameData(); restartAuto();
                }
            });

        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    autoSpeed = progress + 1; saveGameData();
                    if (autoFarmEnabled || autoMineEnabled || autoFishEnabled) restartAuto();
                }
                public void onStartTrackingTouch(SeekBar seekBar) {}
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
    }

    public void doFarming() {
        int harvest = farmSize * (clickPower + random.nextInt(3));
        wheat = wheat + harvest;
        gold = gold + (harvest * 2);
        addExp(harvest);
        tvMessage.setText("🌾 Harvested " + harvest + " wheat! +" + (harvest * 2) + " gold");
        if (random.nextInt(100) < 5) { diamonds = diamonds + 1; tvMessage.setText(tvMessage.getText() + "\n💎 Found a diamond!"); }
        updateUI(); saveGameData();
    }

    public void doMining() {
        int mined = pickaxeLevel * (clickPower + random.nextInt(2));
        ore = ore + mined;
        gold = gold + (mined * 3);
        addExp(mined);
        tvMessage.setText("⛏️ Mined " + mined + " ore! +" + (mined * 3) + " gold");
        if (random.nextInt(100) < 3) { diamonds = diamonds + 2; tvMessage.setText(tvMessage.getText() + "\n💎 Found 2 diamonds!"); }
        updateUI(); saveGameData();
    }

    public void doFishing() {
        int caught = fishingRod * (clickPower + random.nextInt(4));
        fish = fish + caught;
        gold = gold + (caught * 2);
        addExp(caught);
        tvMessage.setText("🎣 Caught " + caught + " fish! +" + (caught * 2) + " gold");
        if (random.nextInt(100) < 8) { diamonds = diamonds + 1; tvMessage.setText(tvMessage.getText() + "\n💎 Found a diamond!"); }
        updateUI(); saveGameData();
    }

    public void chopWood(View v) {
        int chopped = axeLevel * (clickPower + random.nextInt(3));
        wood = wood + chopped;
        gold = gold + chopped;
        addExp(chopped);
        tvMessage.setText("🪓 Chopped " + chopped + " wood! +" + chopped + " gold");
        updateUI(); saveGameData();
    }

    public void gatherShrooms(View v) {
        int gathered = mushroomFarm * (clickPower + random.nextInt(3));
        shroom = shroom + gathered;
        gold = gold + gathered;
        addExp(gathered);
        tvMessage.setText("🍄 Gathered " + gathered + " mushrooms! +" + gathered + " gold");
        updateUI(); saveGameData();
    }

    public void craftSword(View v) {
        int woodCost = 50 + (clickPowerLevel * 10);
        int oreCost = 30 + (clickPowerLevel * 5);
        if (wood >= woodCost && ore >= oreCost) {
            wood = wood - woodCost; ore = ore - oreCost;
            clickPowerLevel = clickPowerLevel + 1;
            clickPower = clickPowerLevel + (level / 5);
            tvMessage.setText("⚔️ Crafted Iron Sword! Click Power +1!");
            updateUI(); saveGameData();
        } else {
            tvMessage.setText("❌ Need " + woodCost + " wood and " + oreCost + " ore!");
        }
    }

    public void craftArmor(View v) {
        int woodCost = 80 + (axeLevel * 20);
        int shroomCost = 20 + (pickaxeLevel * 10);
        if (wood >= woodCost && shroom >= shroomCost) {
            wood = wood - woodCost; shroom = shroom - shroomCost;
            axeLevel = axeLevel + 1; pickaxeLevel = pickaxeLevel + 1;
            tvMessage.setText("🛡️ Crafted Wood Armor! Mining and Woodcutting improved!");
            updateUI(); saveGameData();
        } else {
            tvMessage.setText("❌ Need " + woodCost + " wood and " + shroomCost + " shrooms!");
        }
    }

    public void upgradeFarmSize(View v) {
        int cost = 100 * farmSize;
        if (gold >= cost) { gold = gold - cost; farmSize = farmSize + 1; tvMessage.setText("🌾 Farm upgraded to size " + farmSize); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradeAxe(View v) {
        int cost = 80 * axeLevel;
        if (gold >= cost) { gold = gold - cost; axeLevel = axeLevel + 1; tvMessage.setText("🪓 Axe upgraded to level " + axeLevel); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradeMushroomFarm(View v) {
        int cost = 120 * mushroomFarm;
        if (gold >= cost) { gold = gold - cost; mushroomFarm = mushroomFarm + 1; tvMessage.setText("🍄 Mushroom farm upgraded to level " + mushroomFarm); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradeFishingRod(View v) {
        int cost = 90 * fishingRod;
        if (gold >= cost) { gold = gold - cost; fishingRod = fishingRod + 1; tvMessage.setText("🎣 Fishing rod upgraded to level " + fishingRod); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradePickaxe(View v) {
        int cost = 110 * pickaxeLevel;
        if (gold >= cost) { gold = gold - cost; pickaxeLevel = pickaxeLevel + 1; tvMessage.setText("⛏️ Pickaxe upgraded to level " + pickaxeLevel); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradeClickPower(View v) {
        int cost = 50 * clickPowerLevel;
        if (gold >= cost) { gold = gold - cost; clickPowerLevel = clickPowerLevel + 1; clickPower = clickPowerLevel + (level / 5); tvMessage.setText("🔨 Click Power Level " + clickPowerLevel); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradePassiveIncome(View v) {
        int cost = 150 * (passiveIncomeLevel + 1);
        if (gold >= cost) { gold = gold - cost; passiveIncomeLevel = passiveIncomeLevel + 1; tvMessage.setText("⏰ Passive Income Level " + passiveIncomeLevel); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void upgradeCritChance(View v) {
        int cost = 200 * (critChanceLevel + 1);
        if (gold >= cost) { gold = gold - cost; critChanceLevel = critChanceLevel + 1; tvMessage.setText("✨ Critical Chance Level " + critChanceLevel); updateUI(); saveGameData(); }
        else { tvMessage.setText("❌ Need " + cost + " gold!"); }
    }

    public void sellWheat(View v) { if (wheat >= 10) { wheat = wheat - 10; gold = gold + 5; tvMessage.setText("💰 Sold 10 wheat for 5 gold"); updateUI(); saveGameData(); } else { tvMessage.setText("❌ Need 10 wheat!"); } }
    public void sellWood(View v) { if (wood >= 10) { wood = wood - 10; gold = gold + 4; tvMessage.setText("💰 Sold 10 wood for 4 gold"); updateUI(); saveGameData(); } else { tvMessage.setText("❌ Need 10 wood!"); } }
    public void sellShrooms(View v) { if (shroom >= 10) { shroom = shroom - 10; gold = gold + 8; tvMessage.setText("💰 Sold 10 mushrooms for 8 gold"); updateUI(); saveGameData(); } else { tvMessage.setText("❌ Need 10 shrooms!"); } }
    public void sellFish(View v) { if (fish >= 10) { fish = fish - 10; gold = gold + 10; tvMessage.setText("💰 Sold 10 fish for 10 gold"); updateUI(); saveGameData(); } else { tvMessage.setText("❌ Need 10 fish!"); } }
    public void sellOre(View v) { if (ore >= 5) { ore = ore - 5; gold = gold + 15; tvMessage.setText("💰 Sold 5 ore for 15 gold"); updateUI(); saveGameData(); } else { tvMessage.setText("❌ Need 5 ore!"); } }

    private void addExp(int amount) {
        exp = exp + amount;
        while (exp >= expNeeded) {
            exp = exp - expNeeded;
            level = level + 1;
            expNeeded = (int)(expNeeded * 1.2);
            gold = gold + 200;
            diamonds = diamonds + 10;
            tvMessage.setText("🎉 LEVEL UP! Level " + level + "! +200 Gold, +10 Diamonds!");
        }
    }

    private void startPassiveIncome() {
        passiveRunnable = new Runnable() {
            public void run() {
                if (passiveIncomeLevel > 0) {
                    gold = gold + (passiveIncomeLevel * 10);
                    tvMessage.setText("⏰ Passive income! +" + (passiveIncomeLevel * 10) + " gold");
                    updateUI(); saveGameData();
                }
                handler.postDelayed(this, 30000);
            }
        };
        handler.post(passiveRunnable);
    }

    private void startAutoFeatures() {
        autoRunnable = new Runnable() {
            public void run() {
                if (autoFarmEnabled) doFarming();
                if (autoMineEnabled) doMining();
                if (autoFishEnabled) doFishing();
                saveGameData();
                final int delay = autoSpeed * 2000;
                autoHandler.postDelayed(this, delay);
            }
        };
        if (autoFarmEnabled || autoMineEnabled || autoFishEnabled) {
            final int startDelay = autoSpeed * 2000;
            autoHandler.postDelayed(autoRunnable, startDelay);
        }
    }

    private void restartAuto() {
        if (autoRunnable != null) autoHandler.removeCallbacks(autoRunnable);
        startAutoFeatures();
    }

    private void animateButton(final View v) {
        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).withEndAction(new Runnable() {
                public void run() { v.animate().scaleX(1f).scaleY(1f).setDuration(100).start(); }
            }).start();
    }

    private void toggleMenu() {
        if (menuVisible) { menuPanel.setVisibility(View.GONE); menuVisible = false; }
        else { menuPanel.setVisibility(View.VISIBLE); menuVisible = true; }
    }

    private void toggleForest() {
        if (forestPanel.getVisibility() == View.VISIBLE) { forestPanel.setVisibility(View.GONE); }
        else { forestPanel.setVisibility(View.VISIBLE); craftPanel.setVisibility(View.GONE); }
    }

    private void toggleCraft() {
        if (craftPanel.getVisibility() == View.VISIBLE) { craftPanel.setVisibility(View.GONE); }
        else { craftPanel.setVisibility(View.VISIBLE); forestPanel.setVisibility(View.GONE); }
    }

    private void updateUI() {
        tvLevel.setText(String.valueOf(level));
        tvExp.setText(exp + "/" + expNeeded);
        tvGold.setText(String.valueOf(gold));
        tvDiamonds.setText(String.valueOf(diamonds));
        tvWheat.setText(String.valueOf(wheat));
        tvWood.setText(String.valueOf(wood));
        tvShroom.setText(String.valueOf(shroom));
        tvFish.setText(String.valueOf(fish));
        tvOre.setText(String.valueOf(ore));
        tvFarmSize.setText("Farm: Lvl " + farmSize);
        tvAxeLevel.setText("Axe: Lvl " + axeLevel);
        tvMushroomFarm.setText("Shroom: Lvl " + mushroomFarm);
        tvFishingRod.setText("Rod: Lvl " + fishingRod);
        tvPickaxe.setText("Pickaxe: Lvl " + pickaxeLevel);
        progressExp.setMax(expNeeded);
        progressExp.setProgress(exp);
    }

    private void saveGameData() {
        SharedPreferences prefs = getSharedPreferences("IdleFarmerSave", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("level", level); editor.putInt("exp", exp); editor.putInt("expNeeded", expNeeded);
        editor.putInt("gold", gold); editor.putInt("diamonds", diamonds);
        editor.putInt("wheat", wheat); editor.putInt("wood", wood); editor.putInt("shroom", shroom);
        editor.putInt("fish", fish); editor.putInt("ore", ore);
        editor.putInt("farmSize", farmSize); editor.putInt("axeLevel", axeLevel);
        editor.putInt("mushroomFarm", mushroomFarm); editor.putInt("fishingRod", fishingRod);
        editor.putInt("pickaxeLevel", pickaxeLevel); editor.putInt("clickPowerLevel", clickPowerLevel);
        editor.putInt("passiveIncomeLevel", passiveIncomeLevel); editor.putInt("critChanceLevel", critChanceLevel);
        editor.putBoolean("autoFarmEnabled", autoFarmEnabled); editor.putBoolean("autoMineEnabled", autoMineEnabled);
        editor.putBoolean("autoFishEnabled", autoFishEnabled); editor.putInt("autoSpeed", autoSpeed);
        editor.apply();
    }

    private void loadGameData() {
        SharedPreferences prefs = getSharedPreferences("IdleFarmerSave", MODE_PRIVATE);
        level = prefs.getInt("level", 1); exp = prefs.getInt("exp", 0); expNeeded = prefs.getInt("expNeeded", 100);
        gold = prefs.getInt("gold", 100); diamonds = prefs.getInt("diamonds", 0);
        wheat = prefs.getInt("wheat", 0); wood = prefs.getInt("wood", 0); shroom = prefs.getInt("shroom", 0);
        fish = prefs.getInt("fish", 0); ore = prefs.getInt("ore", 0);
        farmSize = prefs.getInt("farmSize", 1); axeLevel = prefs.getInt("axeLevel", 1);
        mushroomFarm = prefs.getInt("mushroomFarm", 1); fishingRod = prefs.getInt("fishingRod", 1);
        pickaxeLevel = prefs.getInt("pickaxeLevel", 1); clickPowerLevel = prefs.getInt("clickPowerLevel", 1);
        passiveIncomeLevel = prefs.getInt("passiveIncomeLevel", 0); critChanceLevel = prefs.getInt("critChanceLevel", 0);
        autoFarmEnabled = prefs.getBoolean("autoFarmEnabled", false); autoMineEnabled = prefs.getBoolean("autoMineEnabled", false);
        autoFishEnabled = prefs.getBoolean("autoFishEnabled", false); autoSpeed = prefs.getInt("autoSpeed", 3);
        clickPower = clickPowerLevel + (level / 5);
        if (swAutoFarm != null) swAutoFarm.setChecked(autoFarmEnabled);
        if (swAutoMine != null) swAutoMine.setChecked(autoMineEnabled);
        if (swAutoFish != null) swAutoFish.setChecked(autoFishEnabled);
        if (seekSpeed != null) seekSpeed.setProgress(autoSpeed - 1);
    }

    @Override
    protected void onStop() {
        super.onStop();
        showNotification();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (passiveRunnable != null) handler.removeCallbacks(passiveRunnable);
        if (autoRunnable != null) autoHandler.removeCallbacks(autoRunnable);
    }
}
